Calculator
---
<img src="Logotype primary.png" width="60%" height="60%" />

Created with *create-react-app*. See the [full create-react-app guide](https://github.com/facebookincubator/create-react-app/blob/master/packages/react-scripts/template/README.md).



Try It
---

[codeceptjs.github.io/test-react-calculator](https://codeceptjs.github.io/test-react-calculator)



Install
---

`npm install`



Usage
---

`npm start`
